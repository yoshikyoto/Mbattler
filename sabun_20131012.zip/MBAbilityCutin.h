//
//  MBAbilityCutin.h
//  Mbattler
//
//  Created by Yoshiyuki Sakamoto on 2013/10/03.
//  Copyright (c) 2013年 Mbattler. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Meishi.h"

@interface MBAbilityCutin : UIScrollView

- (id)initWithMeishi:(Meishi *)meishi;

@end
