//
//  MBStartView.m
//  Mbattler
//
//  Created by Yoshiyuki Sakamoto on 2013/09/14.
//  Copyright (c) 2013年 Mbattler. All rights reserved.
//

#import "MBStartView.h"

@implementation MBStartView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
