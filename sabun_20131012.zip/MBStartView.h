//
//  MBStartView.h
//  Mbattler
//
//  Created by Yoshiyuki Sakamoto on 2013/09/14.
//  Copyright (c) 2013年 Mbattler. All rights reserved.
//

#import "MBScrollView.h"

@interface MBStartView : MBScrollView

@end
