//
//  BackButton.h
//  Mbattler
//
//  Created by Yoshiyuki Sakamoto on 2013/05/12.
//  Copyright (c) 2013年 Mbattler. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BackButton : UIButton{
}

@end
